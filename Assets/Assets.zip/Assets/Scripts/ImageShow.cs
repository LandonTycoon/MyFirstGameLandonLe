using UnityEngine;

public class ImageShow : MonoBehaviour
{
    public GameObject imageToToggle; // Assign the image GameObject in the Inspector

    public void ToggleImageVisibility()
    {
        if (imageToToggle != null)
        {
            // Toggle the active state of the image
            imageToToggle.SetActive(!imageToToggle.activeSelf);
        }
    }
}
