using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using UnityEngine;

public class ActivationInformation : MonoBehaviour
{
    public List<GameObject> Activate;
    public int price;
    private Vector3 lastPosition;
    private Quaternion lastRotation;
    public string targetTag; // The tag to detect and remove from objects on contact
    public RebirthText rebirthText;

    public GameObject prefab;
    // Start is called before the first frame update
    void Start()
    {
        transform.GetComponentInChildren<TMPro.TMP_Text>().text = $"Price: ${price}";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        HandleContact(other.gameObject);
        if (!gameObject.activeSelf) return;

        if(other.gameObject.CompareTag("Player"))
        {
            if(rebirthText.money >= price) 
            {
                rebirthText.money -= price;
                foreach (var obj in Activate)
                {
                    obj.SetActive(true);
                    gameObject.SetActive(false);
                }
            }
        }
    }
    private void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.CompareTag("Player"));
        {
            Debug.Log("Hawk Tuah!!1");
            HandleContact(other.gameObject);
        }
    }

    private void HandleContact(GameObject other)
    {
        // Check if the other object has the target tag
        // Check if the other object has the tag "button"
        if (other.gameObject.CompareTag("Player") && rebirthText.money >= price)
        {
            // Remove the tag by setting it to "Untagged"
            gameObject.tag = "Untagged";
            Debug.Log($"Tag removed from {other.name}");
        }
    }
}

