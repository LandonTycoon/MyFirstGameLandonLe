using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreditsShow : MonoBehaviour
{
    public GameObject mainMenu;
    public GameObject creditsMenu;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Time.timeScale = 1.0f;
    }

    public void GiveCredits()
    {
        mainMenu.SetActive(false);
        creditsMenu.SetActive(true);
    }

    public void HideCredits()
    {
        mainMenu.SetActive(true);
        creditsMenu.SetActive(false);
    }
}
