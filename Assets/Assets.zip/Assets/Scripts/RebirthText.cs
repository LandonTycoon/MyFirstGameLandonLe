using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RebirthText : MonoBehaviour
{
    public string targetTag;          // The tag to search for
    public Text displayText;          // Reference to the UI Text component
    public bool canRebirth = false;   // Tracks if rebirth is possible

    private int previousCount = -1;   // Keeps track of the previous count to detect changes
    public int price;                 // Price required for rebirth
    private DestroyCube cubeDestroy;  // Reference to the DestroyCube script
    public float money;
    public static float multiplier = 1f; // Current multiplier for rebirth
    private int currentCount = 0;      // Tracks objects with targetTag

    public Text scoreText; // Make sure this is assigned in the inspector

    void Start()
    {
        // Try to find the DestroyCube script in the scene if not assigned
        if (cubeDestroy == null)
        {
            cubeDestroy = FindObjectOfType<DestroyCube>();
        }

        // Ensure the Text component is properly assigned in the inspector
        if (scoreText == null)
        {
            Debug.LogError("ScoreText is not assigned in the inspector.");
        }
      
    }

    void Update()
    {
        // Ensure the targetTag is valid before proceeding
        if (!string.IsNullOrWhiteSpace(targetTag))
        {
            currentCount = CountObjectsWithTagIncludingDisabled(targetTag);

            // Only update UI or logic if the count has changed
            if (currentCount != previousCount)
            {
                UpdateDisplayText(currentCount);
                previousCount = currentCount;
            }

            // Rebirth only if all tagged objects are gone AND money is enough
            canRebirth = (currentCount == 0 && money >= price);

            if (canRebirth)
            {
                Debug.Log("Able to rebirth!");
                
            }
        }

        // Update scoreText to show money every frame
        if (scoreText != null)
        {
            scoreText.text = "Money: " + money.ToString();
        }
    }

    public void ReloadTheScene()
    {
        // Ensure rebirth is allowed before reloading
        if (canRebirth)
        {
            // Increase multiplier on rebirth
            multiplier += 0.2f;

            // Deduct the price and reload the scene
            money -= price;

            // Reload the scene after rebirth
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    int CountObjectsWithTagIncludingDisabled(string tag)
    {
        int count = 0;

        // Loop through all objects in the scene
        foreach (GameObject obj in Resources.FindObjectsOfTypeAll<GameObject>())
        {
            // Check if the object has the target tag and is part of the active scene
            if (!string.IsNullOrEmpty(tag) && obj.CompareTag(tag) && obj.scene.isLoaded)
            {
                count++;
            }
        }

        return count;
    }

    void UpdateDisplayText(int count)
    {
        // Update the UI Text component with the count
        if (displayText != null)
        {
            displayText.text = $"Buttons Remaining: {count}";
        }
    }
}
