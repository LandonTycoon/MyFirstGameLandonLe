using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConveyorButtonTest : MonoBehaviour
{
    [Header("Conveyor & Buttons")]
    public GameObject conveyor;
    public GameObject button;
    public GameObject buttonAfter;

    [Header("Price & Money")]
    public int price;
    public static int money; // Made static to allow global access if needed (optional)

    [Header("Text")]
    public Text scoreText;

    private void Start()
    {
        conveyor.SetActive(false);
        buttonAfter.SetActive(false);
        // Find the instance of DestroyCube once
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            if (money >= price)
            {

                if (conveyor != null)
                {
                    conveyor.SetActive(true);
                    DeductMoney(price);
                    StartCoroutine(DelayButtonTime());
                }
                
            }
        }
    }

    public void DeductMoney(int amount)
    {
        if (money >= amount) // Ensure money doesn't go negative
        {
            money -= amount;
            UpdateScoreText();
        }
        
    }

        public void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = "Money: " + money.ToString();
        }
    }
    
    IEnumerator DelayButtonTime()
    {
        
        yield return new WaitForSeconds(0.3f);
        buttonAfter.SetActive(true);
        Destroy(button);
    }
}
