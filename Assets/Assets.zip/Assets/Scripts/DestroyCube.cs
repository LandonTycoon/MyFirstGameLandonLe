using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyCube : MonoBehaviour
{
    public float moneyDrop = 1;  
    public float upgraderValue = 1;
    public string cubeName;
    public float touched = 0;

    private RebirthText rebirthText;

    private void Start()
    {
        // Try to find "GameObjectRebirth" and get RebirthText component
        GameObject checkObject = GameObject.Find("GameObjectRebirth");
        if (checkObject != null)
        {
            rebirthText = checkObject.GetComponent<RebirthText>();
        }

        // Fallback in case object is not found
        if (rebirthText == null)
        {
            rebirthText = FindObjectOfType<RebirthText>();
        }

        if (rebirthText == null)
        {
            Debug.LogError("RebirthText script not found in the scene!");
            return;
        }

        cubeName = gameObject.name;
        upgraderValue = 1;
    }

    private void OnCollisionEnter(Collision collision)
    {
        string colliderName = collision.gameObject.name;

        if ((colliderName == "UpgraderVeil" && (touched == 0 || touched == 1)) ||
            (colliderName == "UpgraderVeil2" && touched == 0) ||
            (colliderName == "UpgraderVeil3" && (touched == 1 || touched == 2)))
        {
            upgraderValue += (colliderName == "UpgraderVeil3") ? 2 : 1;
            touched += 1;
        }

        if (collision.gameObject.CompareTag("Destroyer")) 
        {
            // Assign moneyDrop value using Dictionary for efficiency
            Dictionary<string, float> cubeValues = new Dictionary<string, float>
            {
                { "SupremeCube(Clone)", 8 },
                { "SpecialCube(Clone)", 5 },
                { "Cube(Clone)", 1 },
                { "MoreCube(Clone)", 2 }
            };

            moneyDrop = cubeValues.ContainsKey(gameObject.name) ? cubeValues[gameObject.name] : 3;

            // Ensure rebirthText is not null before modifying money
            if (rebirthText != null)
            {
                rebirthText.money += moneyDrop * upgraderValue * RebirthText.multiplier;
            }

            Destroy(gameObject);
        }
    }
}
