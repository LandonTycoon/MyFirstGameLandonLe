using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RebirthWork : MonoBehaviour
{
    public Button myButton; // Reference to the Button in your UI
    private const string parentName = "DropperButtons"; // The name of the parent GameObject
    private const string parentName2 = "Droppers"; // The name of the second parent GameObject
    private const string childTag = "button"; // The tag to assign to inactive child GameObjects
    public RebirthText rebirth; // Reference to the RebirthText script

    void Start()
    {
        if (myButton != null)
        {
            // Add a listener to the button
            myButton.onClick.AddListener(AssignTagToInactiveChildren);
        }
    }

    public void AssignTagToInactiveChildren()
    {
        if (rebirth == null)
        {
            Debug.LogError("RebirthText reference is missing!");
            return;
        }
       
        // Trigger only when canRebirth is true
        if (rebirth.canRebirth)
        {
            Debug.Log("Rebirth condition met. Assigning tags to inactive children...");
            rebirth.canRebirth = false; // Reset the rebirth state after execution

            // Find the parent objects
            GameObject parentObject = GameObject.Find(parentName);
            GameObject dropperObject = GameObject.Find(parentName2);

            // Turn off all children in the parentObject and assign the tag
            if (parentObject != null)
            {
                foreach (Transform child in parentObject.transform)
                {
                    child.gameObject.SetActive(false); // Turn off the child
                    child.gameObject.tag = childTag; // Assign the specified tag
                    Debug.Log($"Turned off and assigned tag '{childTag}' to: {child.name}");
                }
            }

            // Turn off all children in the dropperObject
            if (dropperObject != null)
            {
                foreach (Transform child in dropperObject.transform)
                {
                    child.gameObject.SetActive(false); // Turn off the child
                    Debug.Log($"Turned off dropper: {child.name}");
                }
            }
        }
        else
        {
            Debug.Log("Rebirth condition not met.");
        }
    }
}
