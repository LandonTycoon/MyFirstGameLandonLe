using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropperDrop : MonoBehaviour
{
    public GameObject prefabCueb;
    public float spawnInteveral = 2f;
    // Start is called before the first frame update
    private void Start()
    {
        InvokeRepeating("spawnsObject", 0, spawnInteveral);
    }

   

    private void spawnsObject()
    {
        if(gameObject.CompareTag("dropperMore") && this.gameObject != null)
        {
            Instantiate(prefabCueb, transform.position,Quaternion.identity);
        }
        else
        if(this.gameObject != null)
        {
            Instantiate(prefabCueb,transform.position,Quaternion.identity);
        }
    }
} 