using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropperOn : MonoBehaviour
{
    public GameObject dropper; // Reference to the dropper GameObject
    public GameObject button;  // Reference to the button GameObject

    private void Start()
    {
        // Ensure the dropper is initially inactive
        dropper.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        // Check if the object that entered the trigger is the player
        if (other.CompareTag("Player"))
        {
            Debug.Log("Button hit Player");
            // Ensure the dropper is set to active when the player touches the button
            dropper.SetActive(true);
        }
    }
}
