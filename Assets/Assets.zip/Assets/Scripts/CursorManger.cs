using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CursorManger : MonoBehaviour
{
    public GameObject purplePanel;
    public GameObject LetterX;
    public GameObject mainRebirthButton;
    

    // Update is called once per frame
    void Update()
    {
        Cursor.lockState = CursorLockMode.None;
    }

    public void PurplePanelOff()
    {
        LetterX.SetActive(false);
        purplePanel.SetActive(false);
        mainRebirthButton.SetActive(false);
    }

    public void PurplePanelOn()
    {
        LetterX.SetActive(true);
        purplePanel.SetActive(true);
        mainRebirthButton.SetActive(true);
    }
}
