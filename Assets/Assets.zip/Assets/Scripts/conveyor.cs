using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConveyorBelt : MonoBehaviour
{
    [SerializeField]
    private float speed, conveyorSpeed;
    [SerializeField]
    private Vector3 direction;
    [SerializeField]
    private List<GameObject> onBelt;

    private Material material;

    // Start is called before the first frame update
    void Start()
    {
        // Create an instance of this texture
        material = GetComponent<MeshRenderer>().material;
    }

    // Update is called once per frame
    private void Update()
    {
        // Move the conveyor belt texture to make it look like it's moving
        material.mainTextureOffset += new Vector2(0, 1) * conveyorSpeed * Time.deltaTime;
    }

    // Fixed update for physics
    void FixedUpdate()
    {
        // For every item on the belt, add force to it in the direction given
        for (int i = onBelt.Count - 1; i >= 0; i--) // Loop backwards to avoid issues when removing
        {
            if (onBelt[i] != null)
            {
                onBelt[i].GetComponent<Rigidbody>().AddForce(speed * direction);
            }
        }
    }

    // When something collides with the belt
    private void OnCollisionEnter(Collision collision)
    {
        // Add only if it has a Rigidbody
        if (collision.gameObject.TryGetComponent<Rigidbody>(out Rigidbody rb))
        {
            onBelt.Add(collision.gameObject);
        }
    }

    // When something leaves the belt
    private void OnCollisionExit(Collision collision)
    {
    //     // Remove the object and destroy it
        if (onBelt.Remove(collision.gameObject))
        {
            onBelt.Remove(collision.gameObject);
        }
    }
}
